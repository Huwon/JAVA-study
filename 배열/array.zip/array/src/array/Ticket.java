package array;

import java.util.Scanner;

public class Ticket {

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		int rows = 10; // 행 갯수
		int cols = 10; // 열 갯수
		int[][] seats = new int[rows][cols];

		char startRow = 'A'; // 좌석 행 시작 문자

		char cRow; // 행 위치 저장 변수
		int cCol; // 열 위치 저장 변수

		boolean run = true;

		do { // 실행코드
			for(int i = 0; i < cols; i++ ) {
				System.out.print("_");
			}
			
			System.out.print("FRONT SCREEN");
			
			for(int i = 0; i < cols; i++ ) {
				System.out.print("_");
			}
			System.out.println();

			System.out.print(" * "); // 비고
			for (int i = 0; i < cols; i++) { // 열 번호 출력 루프
				System.out.print("[" + (i + 1) + "]");
			}
			System.out.println();

			// 행 + 좌석 출력 : 2차원배열 for 2번 쓰기
			// 행 배열 - seats.length - 문자, 열 배열 seats[i].length
			for (int i = 0; i < seats.length; i++) {
				System.out.println();
				System.out.print(" " + (char) (startRow + i) + " ");

				for (int j = 0; j < seats[i].length; j++) {
					if (seats[i][j] == 0) {
						System.out.print("[□]");
					} else {
						System.out.print("[■]");
					}
				}
				System.out.println();
			}

			System.out.println();
			System.out.print("예약하실 좌석의 행(알파벳 대문자 : A )를 입력해 주세요(예약종료 q) : ");
			cRow = s.next().charAt(0); // 행 한 글자만 입력 받기 위해서 - 입력용
			
			if (cRow == 'q') {
				System.out.println("시스템이 종료 됩니다.");
				break;
			}

			System.out.print("예약하실 좌석의 열 번호를 입력하세요: ");
			cCol = s.nextInt();
			System.out.println("입력하신 좌석의 행은" + cRow + "열은 " + cCol + "입니다.");

			System.out.println("티켓 예매를 완료하시겠습니까? (예: y/아니오: n) ");
			String YN = s.next();

			// 배열 예외 처리
			if(cRow < startRow || cRow > (65+(rows -1)) ) {
				//A 보다 작게 넣던지, cCol갯수 보다 큰지
				System.out.println("선택할 수 없는 행번호입니다. ");
				continue;
			}
			if(cCol < 1 || cCol > cols) { 
				System.out.println("선택할 수 없는 열번호입니다");
				continue;
			}
			
			if (YN.equals("Y") || YN.equals("y")) {
				seats[cRow - 65][cCol - 1] = 1; 
				// A(65)-65 = 0 줄번호, 내가 선택한 가로세로에 1을 넣는다
				System.out.println("티켓 예약이 완료되었습니다.");
			} else {
				System.out.println("티켓 예약이 취소되었습니다.");
				
				//루프종료
				run = false;
			}

			

		} while (run);

	}

}
