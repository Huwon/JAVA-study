package array;

import java.util.Scanner;

public class HotelEx {

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		
		int count;  //객실 수 생성 받아줄 변수생성
		int menu;
		int room_num;
		String name;
		
		HotelDao dao = new HotelDao();
		
		//객실 수 생성
		System.out.print("호텔 객실 생성 > ");
		count = s.nextInt();   //입력은 여기서 하지만 실제 처리는 CreatRoom에서
		
		dao.createRoom(count); 
		
		
		boolean run = true;
		while(run) {
			System.out.println("1.객실예약 | 2.예약취소 | 3.객실현황 | 4.종료 ");
			System.out.print("메뉴 선택> ");
			menu = s.nextInt();
			
			switch(menu) {
			case 1 :
				System.out.print("예약하실 객실 번호를 입력하세요 : ");
				room_num = s.nextInt();   //입력할때는 1,2,3으로 입력
				
				System.out.print("예약하실 고객의 이름을 입력하세요 : ");
				name = s.next();
				
				dao.checkIn(room_num, name);
				break;
				
			case 2 :
				System.out.println("예약 취소하실 객실 번호를 입력하세요 : ");
				room_num = s.nextInt();
				dao.checkOut(room_num);
				
				
			case 3 :
				System.out.println("-----------객실목록-----------");
				dao.listRoom();
				break;
			
			default : 
				System.out.println("프로그램을 종료합니다. ");
				System.exit(0);
				break;
			}
			System.out.println();
		}

	}

}
