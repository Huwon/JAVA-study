package array;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class HotelDao {
	//필드
	String [ ] room = null; //-여러군데에서 사용가능
	final int number = 300;  //3층
	
	
	//객실 수 생성 - 생성자
	public void createRoom(int cr) {
		//배열생성
		room = new String[cr];  //String 타입의cr개수만큼
	}
	
	public void checkIn(int room_num, String name) {
		/*정규식 - regExp
		String regExp = "^[각-힣]*$";
		Pattern p = Pattern.compile(regExp);
		Matcher m = p.matcher(name.trim());
		
		if(!m.matches()) { //regExp에 체크되지 않으면
			System.out.println("사용하실 수 없는 이름입니다. ");
			return;  //프로그램 끝   
		} */
		
		if(room[room_num - 1] != null) {  //기존에 예약된 객실이면 
			System.out.println("현재 예약된 객실입니다. 확인해 주세요. ");
			return;
		}
		
		room[room_num - 1] = name + "님이 객실을 예약하셨습니다. ";  
		//배열은 0부터 시작이라 +1해줌, 배열에 문자열이 저장
		 System.out.println(name + "님" + room_num + "호실에 예약되었습니다.");
	}
	public void checkOut(int room_num) {
		room[room_num -1 ] = null;
		System.out.println("예약이 취소되었습니다. ");
		
	}
	public void listRoom() {
		for(int i = 0; i < room.length; i++ ) { //배열 = 객체 - 초기화 null(예약x)
			if(room[i] == null ) {
				System.out.println((number+i+1) + "호 : 비어있음");
			}else {
				System.out.println((number+i+1) + "호 : " + room[i]);
			}
		}
	}
	
}
